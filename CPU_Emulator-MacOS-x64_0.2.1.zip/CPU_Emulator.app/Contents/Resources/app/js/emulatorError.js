const electron = require('electron');
const app = electron.app;

function buttonClicked(id){
    if (process.platform == 'win32'){
        if(id == "assembler"){
            assembler = require('child_process').execFile('runassembler.bat');
        }
        else if(id == "microassembler"){
            microassembler = require('child_process').execFile('runmicroassembler.bat');
        }
    }
    else if(process.platform == 'darwin'){
        if(id == "assembler"){
            require('child_process').spawn('/Library/Frameworks/Python.framework/Versions/3.8/bin/python3 ../../../assembler/main.py ../../../assembler/code.asm');
        }
        else if(id == "microassembler"){
            require('child_process').spawn('/Library/Frameworks/Python.framework/Versions/3.8/bin/python3 ../../../microassembler/main.py -c ../../../controlmap.json -o ../../../opcodes.json');
        }
    }
}