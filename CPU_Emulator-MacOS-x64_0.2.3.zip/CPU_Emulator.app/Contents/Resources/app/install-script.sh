python3 -m pip install --upgrade pip
python3 -m pip install Flask
python3 -m pip install pyfiglet
python3 -m pip install clint
python3 -m pip install configparser
python3 -m pip install argparse
python3 -m pip install serial
python3 -m pip install paho-mqtt