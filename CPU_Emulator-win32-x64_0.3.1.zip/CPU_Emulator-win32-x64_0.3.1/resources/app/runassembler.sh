pwd
python3 ../../../assembler/main.py ../../../assembler/code.asm