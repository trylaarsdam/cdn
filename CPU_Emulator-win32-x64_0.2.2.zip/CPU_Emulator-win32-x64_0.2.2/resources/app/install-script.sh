/Library/Frameworks/Python.framework/Versions/3.8/bin/python3 -m pip install --upgrade pip
/Library/Frameworks/Python.framework/Versions/3.8/bin/python3 -m pip install Flask
/Library/Frameworks/Python.framework/Versions/3.8/bin/python3 -m pip install pyfiglet
/Library/Frameworks/Python.framework/Versions/3.8/bin/python3 -m pip install clint
/Library/Frameworks/Python.framework/Versions/3.8/bin/python3 -m pip install configparser
/Library/Frameworks/Python.framework/Versions/3.8/bin/python3 -m pip install argparse
/Library/Frameworks/Python.framework/Versions/3.8/bin/python3 -m pip install serial
/Library/Frameworks/Python.framework/Versions/3.8/bin/python3 -m pip install paho-mqtt