const electron = require('electron');
const app = electron.app;

function buttonClicked(id){
    console.log(process.cwd())
    console.log(__dirname)
    process.chdir(__dirname)
    console.log(process.cwd())
    if (process.platform == 'win32'){
        if(id == "assembler"){
            assembler = require('child_process').execFile('runassembler.bat');
        }
        else if(id == "microassembler"){
            microassembler = require('child_process').execFile('runmicroassembler.bat');
        }
    }
    else if(process.platform == 'darwin'){
        if(id == "assembler"){
            require('child_process').spawn('bash', [String(__dirname) + '/runassembler.sh'], {stdio: [process.stdin, process.stdout, process.stderr], detached: false});
        } 
        else if(id == "microassembler"){
            require('child_process').spawn('bash', [String(__dirname) + '/runmicroassembler.sh'], {stdio: [process.stdin, process.stdout, process.stderr], detached: false});
        }
    }
}