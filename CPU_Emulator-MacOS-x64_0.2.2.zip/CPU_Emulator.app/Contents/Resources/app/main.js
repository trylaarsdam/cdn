const electron = require('electron');
const app = electron.app;
const { Menu } = require('electron');
const BrowserWindow = electron.BrowserWindow;
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
const Http = new XMLHttpRequest();
var subpy = null;
var backup_subpy = null;
var mainWindow = null;
var emulatorWindow = null;
const ipc = require('electron').ipcMain
global.uuid = {get: ""};
global.apikey = {get: ""};
global.uuidenter = {status: null};
global.componentSelection = {get: ""}
const { dialog } = require('electron')

app.on('window-all-closed', function() {
  //if (process.platform != 'darwin') {
    app.quit();
  //}
});

var menu = Menu.buildFromTemplate([
  {
    label: 'File',
      submenu: [
        {
          label:'Exit',
          click(){
            app.quit();
          }
        }
      ]
  },
  {
      label: 'Connect',
          submenu: [
          {
            label:'Connect to Photon', 
            click() { 
              uuidInputPage();
            } 
          },
          {
            label:'Select Hardware Components',
            click() {
              componentSelectPage();
            }
          },
      ]
    },
    {
      label: "Blynk",
      submenu: [
        {
          label: "Set API Key",
          click() {
            setAPIKey();
          }
        }
      ]
    },
    {
      label: "Edit",
      submenu: [
          { label: "Undo", accelerator: "CmdOrCtrl+Z", selector: "undo:" },
          { label: "Redo", accelerator: "Shift+CmdOrCtrl+Z", selector: "redo:" },
          { type: "separator" },
          { label: "Cut", accelerator: "CmdOrCtrl+X", selector: "cut:" },
          { label: "Copy", accelerator: "CmdOrCtrl+C", selector: "copy:" },
          { label: "Paste", accelerator: "CmdOrCtrl+V", selector: "paste:" },
          { label: "Select All", accelerator: "CmdOrCtrl+A", selector: "selectAll:" }
      ]
    },
    {
      label: "View",
      submenu: [
        {
          label: "Reload",
          accelerator: "F5",
          click: (item, focusedWindow) => {
            if (focusedWindow) {
              // on reload, start fresh and close any old
              // open secondary windows
              if (focusedWindow.id === 1) {
                BrowserWindow.getAllWindows().forEach(win => {
                  if (win.id > 1) win.close();
                });
              }
              focusedWindow.reload();
            }
          }
        },
        { type: "separator"},
        { role: 'togglefullscreen' },
        { role: 'resetzoom' },
        { role: 'zoomin' },
        { role: 'zoomout' },  
        { type: "separator"},
        {
          label: "Toggle Dev Tools",
          accelerator: "F12",
          click: (item, focusedWindow) => {
            if (focusedWindow) {
              focusedWindow.toggleDevTools();
            }
          }
        }
      ]
  }
])

function uuidSet() {
  //console.log("main.js");
  emulatorWindow.uuidSet();
}

function setAPIKey() {
  if(global.uuid.get != ""){
    inputapikey = new BrowserWindow({width: 400, height: 75, parent: emulatorWindow, webPreferences: {nodeIntegration: true}, frame: false});
    //console.log(input.getParentWindow());
    inputapikey.loadFile("input_blynk.html");
  }
  else {
    dialog.showMessageBox({type: "error", title: "Blynk API Key", message: "You have not defined a UUID!"});
  }
}

function uuidInputPage() {
  //console.log(emulatorWindow);
  input = new BrowserWindow({width: 400, height: 75, parent: emulatorWindow, webPreferences: {nodeIntegration: true}, frame: false});
  //console.log(input.getParentWindow());
  input.loadFile("input.html");
}

function componentSelectPage() {
  if(global.uuid.get != ""){
    select = new BrowserWindow({width: 400, height: 400, parent: emulatorWindow, webPreferences: {nodeIntegration: true}, frame: false})
    select.loadURL("http://localhost:5000/setRealComponents");
  }
  else{
    dialog.showMessageBox({type: "error", title: "Hardware Component Selection", message: "You have not defined a UUID!"});
  }
}

Menu.setApplicationMenu(menu);

app.on('ready', function() {
  // call python?
  mainWindow = new BrowserWindow({width: 800, height: 600, webPreferences: {nodeIntegration: true}, frame: false});
  mainWindow.loadFile('index.html');
  if(process.platform == 'win32'){
    var subpy = require('child_process').spawn('python', ['./main.py']);
  }
  else if(process.platform == 'darwin'){
    var subpy = require('child_process').spawn('/Library/Frameworks/Python.framework/Versions/3.8/bin/python3', ['./main.py']);
    //var subpy = require('child_process').spawn('pwd');
    //var subpy = require('child_process').spawn('open', ['/Applications/Calculator.app']);
  }
  
  //var subpy = require('child_process').spawn('./dist/hello.exe');
  
 
  var rq = require('request-promise');
  var mainAddr = 'http://localhost:5000';

  var openWindow = async function(){
    emulatorWindow = new BrowserWindow({width: 800, height: 600, show: false, webPreferences: {nodeIntegration: true}, frame: true});
    //mainWindow.loadURL('file://' + __dirname + '/index.html');
    emulatorWindow.loadURL('http://localhost:5000');
    emulatorWindow.once('ready-to-show' , () => {
      emulatorWindow.show();
      mainWindow.close();
    })
    ipc.on('uuid', (event, arg) => {
      //console.log(event);
      //console.log(arg);
      emulatorWindow.webContents.send('ping', 'uuid');
    })
    ipc.on('apikey', (event, arg) => {
      //console.log(event);
      //console.log(arg);
      emulatorWindow.webContents.send('ping', 'apikey');
    })
    ipc.on('components', (event, arg) => {
      //console.log(event);
      //console.log(arg);
      //console.log(global.componentSelection.get)
      emulatorWindow.webContents.send('ping', 'component');
    })
    emulatorWindow.on('closed', function() {
      emulatorWindow = null;
      if(subpy != null){
        subpy.kill('SIGINT');
      }
      if(backup_subpy != null){
        backup_subpy.kill('SIGINT');
        if(dependencyManager != null){
          dependencyManager.kill('SIGINT');
        }
      }
    });
  };

  var startUp = function(){
    rq(mainAddr)
      .then(function(htmlString){
        console.log('server started!');
        openWindow();
      })
      .catch(function(err){
        //console.log('waiting for the server start...');
        startUp();
      });
  };

  subpy.on('exit', (code) => {
    console.error(`EMU python child process exited with code ${code}`);
    console.error('EMU Attempting to start backup python child process...')

    if (process.platform == 'win32'){
      console.log(__dirname)
      dependencyManager = require('child_process').spawn('cmd.exe', ['/c', String(__dirname) + '/install-script.bat']);
      dependencyManager.on('exit', (code) => {
        backup_subpy = require('child_process').execFile('python', ['./resources/app/main.py']);
        backup_subpy.stdout.on('data', function(data) {
          console.log(data.toString()); 
        });
        backup_subpy.on('exit', (code) => {
          console.error(`EMU backup python child process exited with code ${code}`);
          console.error("It is likely that your microcode.o or assembled.o files are invalid.");
          errorWindow = new BrowserWindow({width: 400, height: 400, show: true, webPreferences: {nodeIntegration: true}, frame: true});
          errorWindow.loadFile('errorWindow.html');
        });
      });
    }
    else if (process.platform == 'darwin'){
      //var backup_subpy = require('child_process').spawn('open', ['/Applications/Calculator.app']);
      //var backup_subpy = require('child_process').spawn('pwd', {stdio: [process.stdin, process.stdout, process.stderr]});
      console.error("EMU process.cwd = " + String(__dirname) + '/main.py');
      dependencyManager = require('child_process').spawn('bash', [String(__dirname) + '/install-script.sh'], {stdio: [process.stdin, process.stdout, process.stderr], detached: false});    
      dependencyManager.on('exit', (code) => {
        backup_subpy = require('child_process').spawn('/Library/Frameworks/Python.framework/Versions/3.8/bin/python3', [String(__dirname) + '/main.py'], {stdio: [process.stdin, process.stdout, process.stderr], detached: false});
        backup_subpy.on('exit', (code) => {
          console.error(`EMU backup python child process exited with code ${code}`);
          if(code != 0){
            console.error("It is likely that your microcode.o or assembled.o files are invalid.");
            errorWindow = new BrowserWindow({width: 400, height: 400, show: true, webPreferences: {nodeIntegration: true}, frame: true});
            errorWindow.loadFile('errorWindow.html');
          }
        });
      });
    }
  });

  // fire!
  startUp();
  Http.open("GET", "http://localhost:5000");
  Http.send();
  
  Http.onreadystatechange=(e)=>{
    //console.log(Http.responseText)
  }
 

});

