pwd
python3 ../../../microassembler/main.py -c ../../../controlmap.json -o ../../../opcodes.json